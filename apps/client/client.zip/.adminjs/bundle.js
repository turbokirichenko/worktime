(function (React) {
	'use strict';

	function _interopDefault (e) { return e && e.__esModule ? e : { default: e }; }

	var React__default = /*#__PURE__*/_interopDefault(React);

	const Dashboard = () => /*#__PURE__*/React__default.default.createElement("input", null);

	AdminJS.UserComponents = {};
	AdminJS.UserComponents.Dashboard = Dashboard;

})(React);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYnVuZGxlLmpzIiwic291cmNlcyI6WyIuLi9zcmMvY29tcG9uZW50cy9kYXNoYm9hcmQuanN4IiwiZW50cnkuanMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0J1xyXG5cclxuY29uc3QgRGFzaGJvYXJkID0gKCkgPT4gPGlucHV0IC8+XHJcblxyXG5leHBvcnQgZGVmYXVsdCBEYXNoYm9hcmQiLCJBZG1pbkpTLlVzZXJDb21wb25lbnRzID0ge31cbmltcG9ydCBEYXNoYm9hcmQgZnJvbSAnLi4vc3JjL2NvbXBvbmVudHMvZGFzaGJvYXJkJ1xuQWRtaW5KUy5Vc2VyQ29tcG9uZW50cy5EYXNoYm9hcmQgPSBEYXNoYm9hcmQiXSwibmFtZXMiOlsiRGFzaGJvYXJkIiwiUmVhY3QiLCJjcmVhdGVFbGVtZW50IiwiQWRtaW5KUyIsIlVzZXJDb21wb25lbnRzIl0sIm1hcHBpbmdzIjoiOzs7Ozs7O0NBRUEsTUFBTUEsU0FBUyxHQUFHQSxtQkFBTUMsc0JBQUEsQ0FBQUMsYUFBQSxjQUFRLENBQUM7O0NDRmpDQyxPQUFPLENBQUNDLGNBQWMsR0FBRyxFQUFFO0NBRTNCRCxPQUFPLENBQUNDLGNBQWMsQ0FBQ0osU0FBUyxHQUFHQSxTQUFTOzs7Ozs7In0=
