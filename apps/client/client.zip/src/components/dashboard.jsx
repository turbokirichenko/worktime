import React from 'react'

const Dashboard = () => <input />

export default Dashboard