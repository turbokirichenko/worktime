const BRAND_NAME = 'Warehouse service'

export const branding = {
    companyName: BRAND_NAME,
    softwareBrothers: false,
    logo: false,
	favicon: '/favicon.png'
};