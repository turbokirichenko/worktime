AdminJS.UserComponents = {}
import Dashboard from '../src/components/dashboard'
AdminJS.UserComponents.Dashboard = Dashboard