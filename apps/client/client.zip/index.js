import { bootstrap } from "./src/bootstrap.js";

bootstrap()